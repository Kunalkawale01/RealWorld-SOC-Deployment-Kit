# Converting Sigma to Elasticsearch / Kibana queries
Use the Sigma project toolchain (https://github.com/SigmaHQ/sigma) to convert the YAML rules into queries your ELK/Security Onion version can ingest.
Example (local): python3 tools/sigmac -t elastic -c config/elasticsearch.yml detections/sigma/expanded_set/0001_powershell_exec.yml
