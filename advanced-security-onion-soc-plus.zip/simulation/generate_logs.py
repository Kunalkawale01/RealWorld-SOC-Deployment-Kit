#!/usr/bin/env python3
# Safe synthetic log generator for lab testing.
# Writes sample Windows-style and Zeek-style logs to stdout or file for ingestion.
import time, sys
def emit_win_event(eventid, account, src):
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ')} EventID={eventid} Account={account} SrcIP={src}")
def emit_zeek_dns(query):
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ')} DNS_QUERY {query}")
if __name__ == '__main__':
    # Emit credential stuffing sequence (failed x5 then success)
    for i in range(5):
        emit_win_event(4625, 'victim.user', '10.60.0.200')
        time.sleep(0.2)
    emit_win_event(4624, 'victim.user', '10.60.0.200')
    # Emit suspicious PowerShell command marker
    print(f"{time.strftime('%Y-%m-%dT%H:%M:%SZ')} PROCESS_CREATED powershell.exe -enc <DATA_PLACEHOLDER> user:victim.user")
    # Emit long DNS query
    emit_zeek_dns(''.join(['A'*80])+'.lab')
    sys.exit(0)
