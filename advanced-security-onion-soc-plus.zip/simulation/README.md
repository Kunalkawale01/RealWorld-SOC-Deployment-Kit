# Synthetic Event Simulator (Safe)
This simulator generates benign logs designed to trigger your Sigma/Wazuh/Suricata rules in the lab.
It will NOT run exploits; it only emits log lines similar to what an attack would produce to help test detections.
Use Python 3 on the target machine(s) to run the generator.
