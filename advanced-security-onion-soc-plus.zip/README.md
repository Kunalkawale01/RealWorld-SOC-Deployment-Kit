# Advanced Security Onion SOC Lab — PLUS (Ansible, TI, Simulator, Inventory)
Created: 2025-12-03

This upgraded package adds automation, enhanced detections, threat-intel ingestion guidance,
realistic dashboards, a safe synthetic event simulator, asset inventory template, and a vulnerability
scanning overview — all designed for an isolated lab environment for learning and SOC practice.

IMPORTANT: All attack/simulation tools included are benign and generate logs only. No exploit code or offensive payloads.
