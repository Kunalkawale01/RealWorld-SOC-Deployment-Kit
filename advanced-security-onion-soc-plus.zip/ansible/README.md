# Ansible automation for SOC lab (overview)
This folder contains an Ansible playbook and roles to automate:
- Wazuh agent installation (Linux & Windows via WinRM)
- Sysmon deployment on Windows (using sysmon XML)
- Filebeat / File forwarding configuration
- Osquery pack deployment

NOTE: WinRM must be enabled on Windows VMs for Ansible to manage them. Use these playbooks in a lab only.
