# Threat Hunting Notebook (Starter)
Example queries and steps to hunt for common attacker techniques:
- Search for PowerShell commandlines: process.name:powershell.exe AND process.command_line:("-enc" OR "IEX")
- Hunt for DNS anomalies: dns.query_length:>60
- Correlate failed logins and subsequent success across indices using Kibana or Elasticsearch queries.
