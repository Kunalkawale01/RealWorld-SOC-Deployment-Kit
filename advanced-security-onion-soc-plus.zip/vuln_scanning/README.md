# Vulnerability Scanning Overview (Lab-friendly, defensive)
Tools you can use in the lab to discover vulnerabilities and misconfigurations (do NOT scan external networks):
- OpenVAS / Greenbone (community edition) - open-source scanner. Deploy in lab and scan your VMs to obtain CVE lists.
- Nikto - web server scan for test JuiceShop instance (lab-only).
- Lynis - Linux system hardening and checks.
- Nmap (with NSE scripts) - service discovery and version detection (lab-use only).

Recommended flow:
1. Inventory assets (use asset_inventory_template.csv).
2. Run an authenticated OpenVAS scan on non-production lab targets.
3. Triage findings, prioritize by CVSS and asset criticality, and track in remediation backlog.

Legal/ethical: Do not scan or probe systems you do not own or have permission to test.
