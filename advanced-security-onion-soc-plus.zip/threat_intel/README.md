# Threat Intelligence Ingestion (Lab)
This folder explains how to ingest threat intelligence into your SOC (Security Onion + MISP).
Options:
- Deploy a local MISP instance (light) and feed it with community feeds.
- Use MISP API to pull IOCs and enrich events in TheHive or Elasticsearch.
- Use OpenCTI or external feeds (abuseipdb, virustotal) for enrichment (API keys required).
